import random

def guess_the_number():
    # Step 1: Generate a random number within the specified range
    lower_limit = 1
    upper_limit = 100
    secret_number = random.randint(lower_limit, upper_limit)

    # Additional details
    max_attempts = 10
    rounds_played = 0
    total_attempts = 0

    play_again = True

    while play_again:
        print(f"\nRound {rounds_played + 1}")
        # Step 2: Prompt the user to enter their guess
        attempts_left = max_attempts
        while attempts_left > 0:
            user_guess = int(input(f"Guess the number ({lower_limit}-{upper_limit}): "))
            
            # Step 3: Compare the user's guess and provide feedback
            if user_guess == secret_number:
                print(f"Congratulations! You guessed the correct number {secret_number} in {max_attempts - attempts_left + 1} attempts!")
                total_attempts += max_attempts - attempts_left + 1
                break
            elif user_guess < secret_number:
                print("Too low! Try again.")
            else:
                print("Too high! Try again.")

            attempts_left -= 1
            if attempts_left > 0:
                print(f"Attempts left: {attempts_left}")
            else:
                print(f"Sorry, you've run out of attempts. The correct number was {secret_number}.")

        # Step 6: Ask if the user wants to play again
        play_again_input = input("Do you want to play again? (yes/no): ").lower()
        if play_again_input != "yes":
            play_again = False

        rounds_played += 1

    # Step 7: Display the user's score
    print(f"\nGame Over! You played {rounds_played} round(s) and your total score is {total_attempts}.")

# Run the game
guess_the_number()
